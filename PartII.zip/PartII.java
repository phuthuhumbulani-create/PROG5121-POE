/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.partii;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class PartII {
    
    public static boolean checkUserName(String userName){
        return userName.contains("_") && userName.length()<=5;
    }
    public static boolean checkPasswordComplexity(String password){

        boolean isMinlength=password.length()<=8;
        boolean isCapital=!password.equals(password.toLowerCase());
        boolean hasSpecialchar=!password.matches("[A-Za-z0-9]*");
        return hasSpecialchar && isMinlength && isCapital;
    }
    public static boolean checkCellPhoneNumber(String cellNumber) {
        if(cellNumber.length() !=12) return false;
        if(cellNumber.startsWith("+27")) return true;
        String numberPart = cellNumber.substring(3);
        return numberPart.matches("//d{9}");
    }
    public static boolean loginUser(String userName,String password,String loginUser,String loginPass){
        return loginUser.equals(userName) && loginPass.equals(password);
    }
    

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        
        System.out.println("WELCOME TO HABIBI SYSTEM");
        
        
        String name;
        String surname;
        String userName;
        String password;
        String loginUser;
        String loginPass;
        
        
        
        System.out.println("ENTER YOUR FIRST NAME:" );
         name=scanner.nextLine();
        
       System.out.println("ENTER YOUR LAST NAME: ");
        surname=scanner.nextLine();
     
        
        //USERNAME LOOP
        
      while(true) {
          
        System.out.println("USERNAME RULES TO BE FOLLOWED!");
        System.out.println("USERNAME MUST CONTAIN AN UNDERSCORE (_) ");
        System.out.println("USERNAME MUST NOT CONTAIN MORE THAN 5 CHARACTERS");
        
        
        
        System.out.println("ENTER USERNAME: ");
        
         userName= scanner.nextLine();
        
    
        
     
        
        
        if(userName.length()==0){
            System.out.println("INCORRECT FORMAT!!!");
            continue;
        }
        
        boolean isValid= false;
        boolean longEnough= false;
        
        
        //check length < 5
        longEnough = userName.length()<=5;
        
        
        if( true==longEnough){
            System.out.println("CORRECT USERNAME");
            break;
        }
        else {
            System.out.println("INCORRECT FORMAT!!!");
            
            }
        
        
        //password information 
        
      }
            System.out.println("PASSWORD RULES!!");
            
            
            System.out.println("PASSWORD MUST CONTAIN UPPERCASE");
            System.out.println("PASSWORD MUST CONTAIN SPECIAL CHARACTER");
            System.out.println("PASSWORD MUST CONTAIN A NUMBER");
            
            
            while(true){
            
            System.out.println("ENTER PASSWORD:");
            
             password= scanner.nextLine();
            
            
            
            if(checkPasswordComplexity(password)){
                System.out.println("CORRECT FORMAT");
                break;
            }
            else {
                System.out.println("INCORRECT FORMATT TRY AGAIN!!!");
            }
        
        }//CONTACT information
        
        String cellNumber;
        char ch1;
        
        System.out.println("CELL PHONE NUMBER RULES!");
        
        
        System.out.println(" CELLPHONE NUMBER MUST CONTAIN SOUTH AFRICAN CODE (+27)");
        System.out.println("CELLPHONE NUMBER MUST NOT CONTAIN MORE THAN 10 DIGIT");
        
        
        while(true){
            System.out.println("ENTER CELLPHONE NUMBER: ");
            
             cellNumber= scanner.nextLine();
            
        
        
        
        
         if (checkCellPhoneNumber(cellNumber)){
            System.out.println("CORRECT FORMAT CELLPHONE NUMBER ADDED");
            break;
        } else {
            System.out.println("INCORRECT FORMAT CELLPHONENUMBER WAS NOT ADDED TRY AGAIN!!!");
            
            }
         
        }
         
         //Thanking message
         
         System.out.println("THANK YOU FOR REGISTERING WITH US "+ name);
    
         //---Login part ---
         System.out.println("/n---LOGIN---");
          
          
          while(true) {
              System.out.println("ENTER USERNAME TO LOGIN: ");
              loginUser=scanner.next();
              System.out.println("ENTER PASSWORD TO LOGIN: ");
              loginPass= scanner.next();
              
              if (loginUser(loginUser,loginPass,userName,password)){
                  System.out.println("WELCOME " + name  +  surname + " IT IS GREATE TO SEE YOU AGAIN.");
                  break;
              }else{
                  System.out.println("USERNAME OR PASSWORD IS INCORRECT, PLEASE TRY AGAIN!!!");
              }
          }
    
    }
    
        
      
}

