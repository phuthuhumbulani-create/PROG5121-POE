/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.partii;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author user
 */
public class PartIITest {
    
    public PartIITest() {
    }
    
    @BeforeAll
    public static void checkUserName() {
        assertTrue(PartII.checkUserName("abc_"),
            "Username with underscore and <=5 chars should be valid");
    }
    @Test
    public void testInvalidUserName_NoUnderscore() {
        assertFalse(PartII.checkUserName("abcd"),
            "Username without underscore should be invalid");
    }
    @Test
    public void testInvalidUserName_TooLong() {
        assertFalse(PartII.checkUserName("abcde_"),
            "Username longer than 5 chars should be invalid");
    }

    @AfterAll
    public static void checkPasswordComplexity() {
          assertTrue(PartII.checkPasswordComplexity("Passw0rd!"),
            "Password with uppercase, special char, and >=8 chars should be valid");
    }
         @Test
    public void testInvalidPassword_NoUppercase() {
        assertFalse(PartII.checkPasswordComplexity("password1!"),
            "Password missing uppercase should be invalid");
    }
    @Test
    public void testInvalidPassword_NoSpecialChar() {
        assertFalse(PartII.checkPasswordComplexity("Password1"),
            "Password missing special character should be invalid");
    }
    @Test
    public void testInvalidPassword_TooShort() {
        assertFalse(PartII.checkPasswordComplexity("P@ss1"),
            "Password shorter than 8 chars should be invalid");
    }

    
    @BeforeEach
    public  void checkCellPhoneNumber() {
     assertTrue(PartII.checkCellPhoneNumber("+27123456789"),
            "Valid SA number with +27 and 9 digits should be accepted");
    }
    @Test
    public void testInvalidCellPhoneNumber_WrongPrefix() {
        assertFalse(PartII.checkCellPhoneNumber("0123456789"),
            "Number without +27 prefix should be invalid");
    }

    @Test
    public void testInvalidCellPhoneNumber_WrongLength() {
        assertFalse(PartII.checkCellPhoneNumber("+271234567"),
            "Number with incorrect length should be invalid");

    }
    
    @AfterEach
    public void loginUser() {
        assertTrue(PartII.loginUser("user", "pass", "user", "pass"),
            "Login should succeed with matching credentials");
        }

    @Test
    public void testLoginUser_Failure() {
        assertFalse(PartII.loginUser("user", "pass", "user", "wrong"),
            "Login should fail with incorrect password");

    }

    /**
     * Test of checkUserName method, of class PartII.
     */
    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName");
        String userName = "";
        boolean expResult = false;
        boolean result = PartII.checkUserName(userName);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkPasswordComplexity method, of class PartII.
     */
    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        String password = "";
        boolean expResult = false;
        boolean result = PartII.checkPasswordComplexity(password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkCellPhoneNumber method, of class PartII.
     */
    @Test
    public void testCheckCellPhoneNumber() {
        System.out.println("checkCellPhoneNumber");
        String cellNumber = "";
        boolean expResult = false;
        boolean result = PartII.checkCellPhoneNumber(cellNumber);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loginUser method, of class PartII.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        String userName = "";
        String password = "";
        String loginUser = "";
        String loginPass = "";
        boolean expResult = false;
        boolean result = PartII.loginUser(userName, password, loginUser, loginPass);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class PartII.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        PartII.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
